"use strict";
let scores = [];
let scoreStrings = [];
let averageScore = 0;

$(document).ready(function() {

    var displayScores = function() {

        var sum = 0;
        let scoreString = "";
        for (var a = 0; a < scores.length; a++) {

            scoreString += `${scores[a].lastName}, ${scores[a].firstName} : ${scores[a].score}` + '\n';
            // $("#scores").val += scores[a].lastName + "," + scores[a].firstName + ": " + scores[a].score;

            sum += scores[a].score;
        }
        $("#scores").val(scoreString);



        averageScore = (sum / scores.length).toFixed(2);


        //Add score strings to the textarea
        $("#average_score").val(averageScore);



    };

    $("#add_button").click(function() {

        let _firstName = $("#first_name").val();
        let _lastName = $("#last_name").val();
        let _score = $("#score").val();

        // get the add form ready for next entry
        $("#first_name").val("");
        $("#last_name").val("");
        $("#score").val("");
        scores.push({
            firstName: _firstName,
            lastName: _lastName,
            score: Number(_score)
        });

        scoreStrings.push(Number(score));

        $("#first_name").focus();
        // $("#scores").append(_firstName + ', ' + _lastName + ' : ' + _score + '\n');
        displayScores();

    }); // end click()

    $("#clear_button").click(function() {


        // remove the score data from the web page
        $("#average_score").val("");
        $("#scores").val("");
        // scores.length = 0;
        scores = [];

        $("#first_name").focus();
    }); // end click()

    $("#sort_button").click(function() {
        //Sort the scores by last name and re-displays the score information.


        let string = "";
        scores.sort(function(a, b) {
            let nameA = a.lastName.toUpperCase();  // ignore upper and lowercase
            let nameB = b.lastName.toUpperCase();   // ignore uppder and lowercase
            if (nameA < nameB) {
                return -1;
            }
            if (nameA > nameB) {
                return 1;
            }
            return 0;
        });
        $('#scores').val('');
        scores.forEach(function(value) {
            console.log(value);
            string += value.lastName + ', ' + value.firstName + ' : ' + value.score + '\n';
        });
        $('#scores').val(string);


    }); // end click()

    $("#first_name").focus();
}); // end ready()