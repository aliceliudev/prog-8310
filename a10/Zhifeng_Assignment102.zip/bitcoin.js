const config = {
    apiURL: 'https://api.coindesk.com/v1/bpi/currentprice.json',
    currencies: ['USD', 'EUR'],
    updateInterval: 15

};

document.addEventListener('DOMContentLoaded', function() {
    fetchData();
    setInterval(fetchData, 15000);
});

const fetchData = function() {

    fetch(config.apiURL)
        .then(response => response.json())
        .then(renderData);
};


const renderData = function(data) {
    Object.keys(data.bpi).forEach(key => {
        console.log(data.bpi[key]);


    });
    const _priceUsd = document.querySelector('.price-usd');
    _priceUsd.innerHTML = data.bpi.USD.rate;


    const _priceEur = document.querySelector('.price-eur');
    _priceEur.innerHTML = data.bpi.EUR.rate;

    const _priceGbp = document.querySelector('.price-gbp');
    _priceGbp.innerHTML = data.bpi.GBP.rate;


    const _time = document.querySelector('.time_updated');
    _time.innerHTML = data.time.updated;


};


