"use strict";
$(document).ready(function(){
    $("#calculate").click( function() {
        
    }); // end click() method
    
    // set focus on cents text box on initial load
    $("#cents").focus();
            
}); // end ready() method